// For development use this:
//export const base_path = "http://127.0.0.1/PGLife";

// For production use this:
export const base_path = ".";