import React from 'react';

const NoProperty = () => {

  return (
    <div className="no-property-container">
      <p>No PG to list</p>
    </div>
  );
}

export default NoProperty;
